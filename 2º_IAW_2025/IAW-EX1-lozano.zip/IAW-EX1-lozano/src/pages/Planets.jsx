import React from 'react'

export default function Planets() {
    return (
        <div>
            <h1 style={{"text-align":"center"}}>Planets</h1>
        </div>
    )
}
