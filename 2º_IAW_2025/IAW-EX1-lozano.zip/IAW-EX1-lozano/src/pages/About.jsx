import React from 'react'

export default function About() {
  return (
    <div>
      <h1 style={{"text-align":"center"}}>About me</h1>
    </div>
  )
}
