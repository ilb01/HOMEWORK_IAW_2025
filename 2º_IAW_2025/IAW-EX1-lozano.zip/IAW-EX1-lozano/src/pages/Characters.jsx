import React from 'react'
import Card from '../components/Card'
// principal 
export default function Characters() {
    return (
        <div>
            <Card />
        </div>
    )
}
