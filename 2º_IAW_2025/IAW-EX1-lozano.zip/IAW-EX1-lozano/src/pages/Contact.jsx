import React from 'react'

export default function Contact() {
  return (
    <div>
      <h1 style={{"text-align":"center"}}>Contact</h1>
    </div>
  )
}
